/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quickchatfinal;

import java.util.*;
import java.util.regex.Pattern;
import java.io.*;
import java.nio.file.*;
/**
 *
 * @author RC_Student_Lab
 */
public class QuickChatFinal {

    private static final Scanner input = new Scanner(System.in);

    // Account array (limit 15)
    private static final int LIMIT = 15;
    private static final Account[] accounts = new Account[LIMIT];
    private static int count = 0;
    private static String statusMessage = "";

    // Message data
    static int totalMessagesSent = 0;
    static int messageNumber = 0;
    static List<Message> messageHistory = new ArrayList<>();

    // -------------------- ACCOUNT CLASS --------------------
    static class Account {
        String name, surname, cell, userName, passWord;

        Account(String n, String s, String c, String u, String p) {
            name = n;
            surname = s;
            cell = c;
            userName = u;
            passWord = p;
        }
    }

    // -------------------- MESSAGE CLASS --------------------
    static class Message {
        String messageID, hash, recipient, content;

        Message(String id, String hash, String recipient, String content) {
            this.messageID = id;
            this.hash = hash;
            this.recipient = recipient;
            this.content = content;
        }
    }

    // -------------------- MAIN --------------------
    public static void main(String[] args) {
        System.out.println("=== Welcome to QuickChat ===");
        register();
        if (login()) {
            System.out.println(statusMessage);
            runMessageSystem();
        } else {
            System.out.println(statusMessage);
        }
    }

    // -------------------- REGISTRATION --------------------
    public static void register() {
        System.out.println("\n=== Registration ===");

        System.out.print("First name: ");
        String n = input.nextLine();

        System.out.print("Last name: ");
        String s = input.nextLine();

        String u = askUserName();
        String p = askPassword();
        String c = askCell();

        if (count < LIMIT) {
            accounts[count] = new Account(n, s, c, u, p);
            count++;
            System.out.println("Registration successful!");
        } else {
            System.out.println("Sorry, registration list full.");
        }
    }

    private static String askUserName() {
        while (true) {
            System.out.print("Choose username (underscore + max 5 chars): ");
            String u = input.nextLine();
            if (u.contains("_") && u.length() <= 5) {
                return u;
            }
            System.out.println("Invalid username, try again.");
        }
    }

    private static String askPassword() {
        while (true) {
            System.out.print("Choose password (8+ chars, 1 capital, 1 number, 1 special): ");
            String p = input.nextLine();
            if (Pattern.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&*()_+=\\-{}\\[\\]:;\"'<>,.?/~`|]).{8,}$", p)) {
                return p;
            }
            System.out.println("Weak password, try again.");
        }
    }

    private static String askCell() {
        while (true) {
            System.out.print("Enter cell (+27xxxxxxxxx): ");
            String c = input.nextLine();
            if (Pattern.matches("^\\+27\\d{9}$", c)) {
                return c;
            }
            System.out.println("Invalid cell, try again.");
        }
    }

    // -------------------- LOGIN --------------------
    public static boolean login() {
        System.out.println("\n=== Login ===");
        System.out.print("Username: ");
        String u = input.nextLine();

        for (int i = 0; i < count; i++) {
            Account acc = accounts[i];
            if (acc.userName.equals(u)) {
                int attempts = 3;
                while (attempts > 0) {
                    System.out.print("Password: ");
                    String p = input.nextLine();
                    if (acc.passWord.equals(p)) {
                        statusMessage = "Welcome back " + acc.name + " " + acc.surname + "!";
                        return true;
                    }
                    attempts--;
                    System.out.println("Wrong password. Attempts left: " + attempts);
                }
                statusMessage = "Login failed. Exiting program.";
                return false;
            }
        }
        statusMessage = "User not found. Please register first.";
        return false;
    }

    // -------------------- MAIN MENU --------------------
    public static void runMessageSystem() {
        boolean keepRunning = true;

        while (keepRunning) {
            System.out.println("\nQuickChat Menu:");
            System.out.println("1. Send Messages");
            System.out.println("2. View Sent Messages");
            System.out.println("3. Search Messages by Recipient");
            System.out.println("4. Delete Message by Hash");
            System.out.println("5. Display Report");
            System.out.println("6. Read Stored Messages (JSON)");
            System.out.println("7. Quit QuickChat");
            System.out.print("Choose an option: ");
            String choice = input.nextLine();

            switch (choice) {
                case "1" -> sendMessages();
                case "2" -> viewSentMessages();
                case "3" -> searchMessages();
                case "4" -> deleteMessage();
                case "5" -> displayReport();
                case "6" -> readMessagesFromJSON();
                case "7" -> {
                    keepRunning = false;
                    System.out.println("Exiting QuickChat...");
                }
                default -> System.out.println("Invalid choice. Try again.");
            }
        }
    }

    // -------------------- SENDING MESSAGES --------------------
    public static void sendMessages() {
        System.out.print("How many messages would you like to send? ");
        int count;
        try {
            count = Integer.parseInt(input.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid number. Returning to menu.");
            return;
        }

        for (int i = 0; i < count; i++) {
            messageNumber++;
            String messageID = generateMessageID();

            System.out.print("Enter recipient number (+27xxxxxxxxx): ");
            String recipient = input.nextLine();
            if (!recipient.matches("^\\+27\\d{9}$")) {
                System.out.println("Invalid recipient number.");
                i--;
                continue;
            }

            System.out.print("Enter message (max 250 characters): ");
            String message = input.nextLine();
            if (message.length() > 250) {
                System.out.println("Message too long by " + (message.length() - 250) + " characters.");
                i--;
                continue;
            }

            String hash = generateMessageHash(messageID, messageNumber, message);

            System.out.println("Choose action: 1 = Send, 2 = Disregard, 3 = Store");
            String action = input.nextLine();

            switch (action) {
                case "1" -> {
                    totalMessagesSent++;
                    messageHistory.add(new Message(messageID, hash, recipient, message));
                    System.out.println("Message sent successfully!");
                }
                case "2" -> System.out.println("Message disregarded.");
                case "3" -> {
                    messageHistory.add(new Message(messageID, hash, recipient, message));
                    writeMessageToJSON(messageID, hash, recipient, message);
                    System.out.println("Message stored.");
                }
                default -> System.out.println("Invalid action. Message disregarded.");
            }
        }
        System.out.println("Total messages sent: " + totalMessagesSent);
    }

    // -------------------- VIEW SENT --------------------
    public static void viewSentMessages() {
        if (messageHistory.isEmpty()) {
            System.out.println("No messages have been sent yet.");
            return;
        }

        System.out.println("\n=== Sent Messages ===");
        for (Message msg : messageHistory) {
            System.out.println("ID: " + msg.messageID + " | Recipient: " + msg.recipient + " | Message: " + msg.content);
        }
    }

    // -------------------- SEARCH MESSAGE --------------------
    public static void searchMessages() {
        System.out.print("Enter recipient number to search (+27xxxxxxxxx): ");
        String number = input.nextLine();

        boolean found = false;
        for (Message msg : messageHistory) {
            if (msg.recipient.equals(number)) {
                System.out.println("Found Message → ID: " + msg.messageID + " | " + msg.content);
                found = true;
            }
        }
        if (!found) {
            System.out.println("No messages found for this recipient.");
        }
    }

    // -------------------- DELETE MESSAGE --------------------
    public static void deleteMessage() {
        System.out.print("Enter message hash to delete: ");
        String hash = input.nextLine();

        boolean deleted = messageHistory.removeIf(msg -> msg.hash.equalsIgnoreCase(hash));
        if (deleted) {
            System.out.println("Message deleted successfully.");
        } else {
            System.out.println("No message found with that hash.");
        }
    }

    // -------------------- DISPLAY REPORT --------------------
    public static void displayReport() {
        System.out.println("\n=== Message Report ===");
        System.out.println("Total messages sent: " + totalMessagesSent);
        System.out.println("Total stored messages: " + messageHistory.size());
        System.out.println("Longest message: " + findLongestMessage());
    }

    public static String findLongestMessage() {
        String longest = "";
        for (Message msg : messageHistory) {
            if (msg.content.length() > longest.length()) {
                longest = msg.content;
            }
        }
        return longest.isEmpty() ? "No messages yet." : longest;
    }

    // -------------------- JSON READ/WRITE --------------------
    public static void writeMessageToJSON(String messageID, String hash, String recipient, String message) {
        StringBuilder jsonEntry = new StringBuilder();
        jsonEntry.append("{\n");
        jsonEntry.append("  \"MessageID\": \"").append(messageID).append("\",\n");
        jsonEntry.append("  \"MessageHash\": \"").append(hash).append("\",\n");
        jsonEntry.append("  \"Recipient\": \"").append(recipient).append("\",\n");
        jsonEntry.append("  \"Message\": \"").append(message.replace("\"", "\\\"")).append("\"\n");
        jsonEntry.append("},\n");

        try (FileWriter file = new FileWriter("JsonMessages.json", true)) {
            file.write(jsonEntry.toString());
        } catch (IOException e) {
            System.out.println("Error writing file: " + e.getMessage());
        }
    }

    public static void readMessagesFromJSON() {
        System.out.println("\n=== Reading Stored Messages from JSON ===");
        try {
            List<String> lines = Files.readAllLines(Paths.get("JsonMessages.json"));
            for (String line : lines) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println("Error reading file or file not found.");
        }
    }

    // -------------------- HELPERS --------------------
    public static String generateMessageID() {
        return String.format("%010d", new Random().nextInt(1_000_000_000));
    }

    public static String generateMessageHash(String id, int num, String msg) {
        String[] words = msg.trim().split(" ");
        String first = words[0];
        String last = words[words.length - 1];
        return (id.substring(0, 2) + ":" + num + ":" + first + last).toUpperCase();
    }
}
