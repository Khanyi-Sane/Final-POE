/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.quickchatfinal;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_Lab
 */
public class QuickChatFinalTest {
    
    public QuickChatFinalTest() {
    }

    /**
     * Test of main method, of class QuickChatFinal.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        QuickChatFinal.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of register method, of class QuickChatFinal.
     */
    @Test
    public void testRegister() {
        System.out.println("register");
        QuickChatFinal.register();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of login method, of class QuickChatFinal.
     */
    @Test
    public void testLogin() {
        System.out.println("login");
        boolean expResult = false;
        boolean result = QuickChatFinal.login();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of runMessageSystem method, of class QuickChatFinal.
     */
    @Test
    public void testRunMessageSystem() {
        System.out.println("runMessageSystem");
        QuickChatFinal.runMessageSystem();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of sendMessages method, of class QuickChatFinal.
     */
    @Test
    public void testSendMessages() {
        System.out.println("sendMessages");
        QuickChatFinal.sendMessages();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of viewSentMessages method, of class QuickChatFinal.
     */
    @Test
    public void testViewSentMessages() {
        System.out.println("viewSentMessages");
        QuickChatFinal.viewSentMessages();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchMessages method, of class QuickChatFinal.
     */
    @Test
    public void testSearchMessages() {
        System.out.println("searchMessages");
        QuickChatFinal.searchMessages();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deleteMessage method, of class QuickChatFinal.
     */
    @Test
    public void testDeleteMessage() {
        System.out.println("deleteMessage");
        QuickChatFinal.deleteMessage();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayReport method, of class QuickChatFinal.
     */
    @Test
    public void testDisplayReport() {
        System.out.println("displayReport");
        QuickChatFinal.displayReport();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of findLongestMessage method, of class QuickChatFinal.
     */
    @Test
    public void testFindLongestMessage() {
        System.out.println("findLongestMessage");
        String expResult = "";
        String result = QuickChatFinal.findLongestMessage();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of writeMessageToJSON method, of class QuickChatFinal.
     */
    @Test
    public void testWriteMessageToJSON() {
        System.out.println("writeMessageToJSON");
        String messageID = "";
        String hash = "";
        String recipient = "";
        String message = "";
        QuickChatFinal.writeMessageToJSON(messageID, hash, recipient, message);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of readMessagesFromJSON method, of class QuickChatFinal.
     */
    @Test
    public void testReadMessagesFromJSON() {
        System.out.println("readMessagesFromJSON");
        QuickChatFinal.readMessagesFromJSON();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of generateMessageID method, of class QuickChatFinal.
     */
    @Test
    public void testGenerateMessageID() {
        System.out.println("generateMessageID");
        String expResult = "";
        String result = QuickChatFinal.generateMessageID();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of generateMessageHash method, of class QuickChatFinal.
     */
    @Test
    public void testGenerateMessageHash() {
        System.out.println("generateMessageHash");
        String id = "";
        int num = 0;
        String msg = "";
        String expResult = "";
        String result = QuickChatFinal.generateMessageHash(id, num, msg);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
